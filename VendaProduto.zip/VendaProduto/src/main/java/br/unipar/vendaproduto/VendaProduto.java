/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package br.unipar.vendaproduto;

import br.unipar.vendaproduto.model.Dados;
import br.unipar.vendaproduto.panels.VendaFrame;



/**
 *
 * @author muril
 */
public class VendaProduto{
    


    public static void main(String[] args) {
        Dados msDados = new Dados();
        VendaFrame venda = new VendaFrame();
        venda.setLocationRelativeTo(null);
        venda.setVisible(true);
        
        

}
}
