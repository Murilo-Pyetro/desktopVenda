/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.unipar.vendaproduto.connection;

import java.sql.Connection;
import java.sql.Driver;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class Conexao {
    
    private String url;
    private String usuario;
    private String senha;
    private Connection con;
    
    public Conexao(){
        url = "jdbc:postgresql://localhost:5432/desktopVenda";
        usuario = "postgres";
        senha = "murilo29";
        
        try {
            
            Class.forName("org.postgresql.Driver");
            con = DriverManager.getConnection(url, usuario, senha);
            System.out.println("Conectado!");
            
        } catch (Exception e) {
            e.printStackTrace();
        }
        
    }
    
    public ResultSet getAll(String sql){
        
        try {
            
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery(sql);
            con.close();
            return rs;
            
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
        
    }
    

    
}
