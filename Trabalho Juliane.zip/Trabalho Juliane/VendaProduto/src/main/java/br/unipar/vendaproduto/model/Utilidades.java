/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.unipar.vendaproduto.model;

/**
 *
 * @author muril
 */
public class Utilidades {
    
    public static boolean isNumeric(String Numero){
        try {
            Integer.parseInt(Numero);
            return true;
        } catch (NumberFormatException nfe) {
            
            return false;
        }
    }
    
}
