/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.unipar.vendaproduto.model;

/**
 *
 * @author muril
 */
public class Dados {
    
 private int MaxCad = 10;   
 private Cliente msclientes[] = new Cliente[10];
 
 private int ContCli = 0;
 
 public Dados(){
 }
 
 public String deletarClientes(int pos){
     
     for (int i = pos; i < ContCli; i++) {
         msclientes[i] = msclientes[i + 1];
     }
     ContCli--;
     return "Cliente Removido com Sucesso!";
 }
 
    
}
