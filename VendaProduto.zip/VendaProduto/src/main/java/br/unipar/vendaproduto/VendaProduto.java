/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package br.unipar.vendaproduto;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;

/**
 *
 * @author muril
 */
public class VendaProduto extends JFrame {
    


    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
               // EntityManagerUtil.getEntityManagerFactory();
                VendaProduto vendaProduto = new VendaProduto();
                vendaProduto.setVisible(true);
            }
        });
    }
}
