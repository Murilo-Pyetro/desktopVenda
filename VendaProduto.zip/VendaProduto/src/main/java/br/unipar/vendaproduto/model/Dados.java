/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.unipar.vendaproduto.model;

/**
 *
 * @author muril
 */
public class Dados {
    
 private int MaxCad = 10;   
 private Cliente msclientes[] = new Cliente[10];
 
 private int ContCli = 0;
 
 public Dados(){
     Cliente Mcliente = new Cliente(1 ,"Frabel","85258426","741589541");
     msclientes[ContCli] = Mcliente;
     ContCli++;
 }
 
 public String deletarClientes(int pos){
     
     for (int i = pos; i < ContCli; i++) {
         msclientes[i] = msclientes[i + 1];
     }
     ContCli--;
     return "Cliente Removido com Sucesso!";
 }
 
 public String adicionarClientes(Cliente msCliente){
     if(ContCli == MaxCad){
         return "NÃO É POSSSIVEL CADASTRAR MAIS CLIENTES (MÁXIMO ATINGIDO)";
     }
     msclientes[ContCli] = msCliente;
     ContCli++;
     return "CLIENTE CADASTRADO COM SUCESSO";
 }
    
}
